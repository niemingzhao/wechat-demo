module.exports = {
  appId: 'wxbd0fb5e654d7e8c1',
  appSecret: '5862a9295838ccc4fc58ec0be13f39a2',
  serverUrl: 'https://circle.bxv8.com/'
  // serverUrl: 'http://wfyerpqd.6655.la:63343/'
  // serverUrl: 'http://wfyerpqd.6655.la:63343/bxwxsvr/BX_UNI_SERVICE.json?method=forumService'
  // serverUrl: 'https://circle.bxv8.com/bxwxsvr/BX_UNI_SERVICE.json'
}